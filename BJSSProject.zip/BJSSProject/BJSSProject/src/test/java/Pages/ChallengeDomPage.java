package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import stepDefs.StepDefs;

public class ChallengeDomPage extends StepDefs {
	WebDriver driver;

	public ChallengeDomPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@class=\"button alert\"]")
	public WebElement bizbutton;

	@FindBy(xpath = "//*[@id='content']/div/h3")
	public WebElement pageHeadder;

	public String getPageHeadder() {
		return pageHeadder.getText();
	}

	public void clickOnAlertButton() {
		bizbutton.click();
	}

	public String getAlertButtonText() {
		return bizbutton.getText();
	}

}
