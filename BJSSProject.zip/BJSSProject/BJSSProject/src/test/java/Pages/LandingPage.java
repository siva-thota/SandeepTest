package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import stepDefs.StepDefs;

public class LandingPage extends StepDefs {
	WebDriver driver;

	public LandingPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id=\"content\"]/ul/li[5]/a")
	public WebElement ChallengingDOM;

	@FindBy(xpath = "//*[@id=\"content\"]/ul/li[14]/a")
	public WebElement dynamicLoadingLink;

	public String getPageTitle() {
		return driver.getTitle();
	}

	public void clickOnChanllengingDom() {
		ChallengingDOM.click();
	}

	public void clickOnDynamicallyLoading() {
		dynamicLoadingLink.click();
	}

}
