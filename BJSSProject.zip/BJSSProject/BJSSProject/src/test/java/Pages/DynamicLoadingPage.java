package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import stepDefs.StepDefs;

public class DynamicLoadingPage extends StepDefs {

	private WebDriver driver;

	public DynamicLoadingPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id=\'content\']/div/a[2]")
	public WebElement ElementRenderedAfterTheFact;

	@FindBy(xpath = "//*[@id='start']/button")
	public WebElement start;

	@FindBy(xpath = "//*[@id=\"finish\"]/h4")
	public WebElement hello;

	@FindBy(xpath = "//*[@id='content']/div/h3")
	public WebElement DyanamicLoadingPageHeadder;

	@FindBy(xpath = "//*[@id='loading']")
	public WebElement LoadingImage;

	public String getPageHeadder() {
		return DyanamicLoadingPageHeadder.getText();
	}

	public void clickOnElementRenderedAfterTheFact() {
		ElementRenderedAfterTheFact.click();
	}

	public void clickOnStartButton() {
		start.click();
	}

	public Boolean confirmLoadingInProgress() throws InterruptedException {
		return LoadingImage.isDisplayed();
	}

	public Boolean confirmHelloWorldIsPresent() {
		WebElement dynamicElement = (new WebDriverWait(driver, 10))
				.until(ExpectedConditions.presenceOfElementLocated(By.id("finish")));
		return dynamicElement.isDisplayed();
	}

	public String getFinishText() {
		return hello.getText();
	}

}
