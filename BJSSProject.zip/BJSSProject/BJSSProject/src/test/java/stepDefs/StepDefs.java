package stepDefs;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import APITest.RestAPI;
import Pages.DynamicLoadingPage;
import Pages.ChallengeDomPage;
import Pages.LandingPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {
	WebDriver driver;
	private static String userPath = System.getProperty("user.dir");
	public static String AlertButtonTextBeforeClicking = null;
	public static String AlertButtonTextAfterClicking = null;

	@Given("^I am on internet.herokuapp page$")
	public void i_am_on_internet_herokuapp_page() {
		System.setProperty("webdriver.chrome.driver", userPath + "/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://the-internet.herokuapp.com/");
	}

	@When("^I click on challengingDom button$")
	public void i_click_on_challengingDom_button() throws Throwable {
		new LandingPage(driver).clickOnChanllengingDom();
	}

	@When("^I navigated to challengingDom Page$")
	public void i_navigated_to_challengingDom_Page() throws Throwable {
		Assert.assertEquals("Challenging DOM", new ChallengeDomPage(driver).getPageHeadder());
	}

	@When("^I click on alert button$")
	public void i_click_on_alert_button() throws Throwable {
		new ChallengeDomPage(driver).clickOnAlertButton();
	}

	@Then("^I copy the alert button text before clicking$")
	public void i_copy_the_alert_button_text() throws Throwable {
		AlertButtonTextBeforeClicking = new ChallengeDomPage(driver).getAlertButtonText();
	}

	@When("^I copy the alert button text after clicking$")
	public void i_copy_the_alert_button_text_after_clicking() throws Throwable {
		AlertButtonTextAfterClicking = new ChallengeDomPage(driver).getAlertButtonText();
	}

	@When("^I confirm the alert button text label changed$")
	public void i_confirm_the_alert_button_text_label_changed() throws Throwable {
		Assert.assertFalse(AlertButtonTextBeforeClicking.contentEquals(AlertButtonTextAfterClicking));
		System.out.println("Button text BEFORE clicking the button: " + AlertButtonTextBeforeClicking + "\n"
				+ "Button text BEFORE clicking the button :" + AlertButtonTextAfterClicking);
		driver.quit();
	}

	@When("^I click on Dynamically Loading button$")
	public void i_click_on_Dynamically_Loading_button() throws Throwable {
		new LandingPage(driver).clickOnDynamicallyLoading();
	}

	@Then("^I navigated to Dynamically Loaded Page Elements Page$")
	public void i_navigated_to_Dynamically_Loaded_Page_Elements_Page() throws Throwable {
		Assert.assertEquals("Dynamically Loaded Page Elements", new DynamicLoadingPage(driver).getPageHeadder());
	}

	@Then("^I click on Element rendered after the fact button$")
	public void i_click_on_Element_rendered_after_the_fact_button() throws Throwable {
		new DynamicLoadingPage(driver).clickOnElementRenderedAfterTheFact();
	}

	@Then("^I click on Start button$")
	public void i_click_on_Start_button() throws Throwable {
		new DynamicLoadingPage(driver).clickOnStartButton();
	}

	@Then("^I see loading is in progress$")
	public void i_see_loading_is_in_progress() throws Throwable {
		Assert.assertTrue(new DynamicLoadingPage(driver).confirmLoadingInProgress());
	}

	@Then("^I confirm the text \"(.*?)\" on the page\\.$")
	public void i_confirm_the_text_on_the_page(String ValidationString) throws Throwable {
		Assert.assertTrue(new DynamicLoadingPage(driver).confirmHelloWorldIsPresent());
		Assert.assertEquals(ValidationString, (new DynamicLoadingPage(driver).getFinishText()));
		driver.quit();
	}

	@When("^I make a post request$")
	public void i_make_a_post_request() throws Throwable {
		RestAPI.postEmployee();
	}

	@Then("^I get a valid response$")
	public void i_get_a_valid_response() throws Throwable {
		RestAPI.validateSuccessResponse();
	}

	@Then("^I get response code as \"(.*?)\"$")
	public void i_get_response_code_as(int responsecode) throws Throwable {
		Assert.assertEquals(responsecode, RestAPI.getResponse());
	}

}
