
package APITest;

import io.restassured.response.Response;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class RestAPI {

	private static Response response = null;

	public static void postEmployee() {
		String newUser = "User"+Math.random();
		RestAssured.baseURI = "http://dummy.restapiexample.com";

		String payload = "{\n" +
			       "  \"name\": \""+newUser+"\",\n" + 
				   "  \"salary\": \"1000\",\n" + 
				   "  \"age\": \"26\"\n" +
				   "}";

		try {
			response = RestAssured.given().contentType(ContentType.JSON).body(payload).post("/api/v1/create");
		} catch (Exception e) {

		}
		
	}

	public static void validateSuccessResponse() {
		System.out.println("Response :" + response.asString());
		Assert.assertFalse(response.asString().contains("error"));
	}

	public static int getResponse() {
		System.out.println("Status Code :" + response.getStatusCode());
		return response.getStatusCode();
	}

}
